<?php
session_start();
require_once 'database.php';
$message = '';

try {
     if(isset($_POST["submit"]))  
     {  
          if(empty($_POST["username"]) || empty($_POST["password"]))  
          {  
               //echo '<label>All fields are required</label>';  
          }  
          else  
          {  
               $query = "SELECT * FROM gegevens WHERE username = :username AND password = :password";  
               $statement = $connect->prepare($query);  
               $statement->execute(  
                    array(  
                         'username'     =>     $_POST["username"],  
                         'password'     =>     $_POST["password"]  
                    )  
               );  
               $count = $statement->rowCount();  
               if($count > 0)  
               {  
                    $_SESSION["username"] = $_POST["username"];  
                    header("location:login_succes.php");  
               }  
               else  
               {  
                    echo '<label>Wrong Data</label>';  
               }  
          }  
     }  
}  
catch(PDOException $error)  
{  
     $message = $error->getMessage();  
}  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body id="inloggen">
<nav class="navbar navbar-expand-lg navbar-light bg-company-red" style="border:none;">
        <div class="container-fluid">
          <a class="navbar-brand" href="#"><img src="images/netflixlogo.png" style="margin: 0.5em 0 0 1em;" class="img-fluid"></a>
            <ul class="navbar-nav ml-auto">
            </ul>
          </div>
        </div>
      </nav>

   <div class="container h-100">
    <div class="row h-100 justify-content-center align-items-center">
        <div class="col-10 col-md-8 col-lg-6">
            <form class="form-example" method="post">
                <h2 style="font-weight:bold;color:#fff;padding-bottom:1em;">Inloggen</h2>
                <div class="form-group">
                    <input type="text" name="username" class="form-control username" id="form" required placeholder="Email address" >
                </div>
                <div class="form-group">
                    <input type="password" name="password" class="form-control password" id="form" required placeholder="Voeg een wachtwoord toe">
                </div>
                <div class="form-group">
                     <input type="submit" name="submit" class="form-control" id="inlogbutton" value="Inloggen"/>
                    </div>
                    <div class="tekst">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                            Mijn gegevens onthouden
                        </label>
                        <label class="form-check-label" for="flexCheckDefault" id="hulp">
                            Hulp nodig?
                        </label>
                    </div>
               </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>