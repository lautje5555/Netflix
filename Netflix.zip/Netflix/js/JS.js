$(document).ready(function(){ // force refresh from top
    $(this).scrollTop(1);
});

$(window).resize(function() {
    if ($(window).width() < 992) {
        $(".navbar-brand").css('margin-left', '0');
    }
    else {
        $(".navbar-brand").css('margin-left', '10%');
    }
    });

    if ($(window).width() < 992) {
        $(".navbar-brand").css('margin-left', '0');
    }

    $(".nav-link").click(function(e) {
    e.preventDefault();
    var aid = $(this).attr("href");
    $('html,body').animate({scrollTop: $(aid).offset().top},'fast');
    });

    $('.navbar-nav>li>a').on('click', function(){
        $('.navbar-collapse').collapse('hide');
    });