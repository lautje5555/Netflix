<?php
require_once 'database.php';

try {
    if(isset($_POST["submit"])){
        if(empty($_POST["Email"]) || empty($_POST["Wachtwoord"]))  
          {  
               //echo '<label>All fields are required</label>';  
          }  
          else{
                $email = $_POST["Email"];
                $wachtwoord = $_POST["Wachtwoord"];

                $connect->exec("INSERT INTO gegevens (username, password) 
                VALUES (\"$email\", \"$wachtwoord\")");
          }
    }
    
} catch(PDOException $e) {
    //echo "Connection failed: " . $e->getMessage()
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link type="text/css" rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-company-red">
        <div class="container-fluid">
          <a class="navbar-brand" href="#"><img src="images/netflixlogo.png" style="margin: 0.5em 0 0 1em;" class="img-fluid"></a>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="pdo_inloggen.php">Inloggen</a>
                </li>
            </ul>
          </div>
        </div>
      </nav>
      
    <div class="container h-100">
    <div class="row h-100 justify-content-center align-items-center">
        <div class="col-10 col-md-8 col-lg-6">

            <form class="form-example" method="post" style="background-color:#fff !important;">
                <h4 style="font-weight:bold;">Verzin een wachtwoord om je <br>lidmaatschap te starten.</h4>
                <p class="description">Nog een paar stappen en je bent klaar!<br>
                    We houden ook niet van te veel administratie.</p>
                <div class="form-group">
                    <input type="text" name="Email" class="form-control username" required placeholder="Email address">
                </div>
                <div class="form-group">
                    <input type="password" name="Wachtwoord" class="form-control password" required placeholder="Voeg een wachtwoord toe">
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" >
                    <label class="form-check-label" for="flexCheckDefault">
                        Ja, stuur mij speciale aanbiedingen van Netflix
                    </label>
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" class="form-control" id="inlogbutton" value="Account aanmaken"/>
                </div>
            </form>
        </div>
    </div>
</div>


</body>
</html>