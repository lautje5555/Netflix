<?php

//Our server/host parameter.
$servername = 'localhost';

//Our MySQL username.
$username = 'root';

$dbName = "netflix";

//Attempt to connect.
$connect = new PDO("mysql:host=$servername;dbname=$dbName", $username);
$connect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

/*Check if we are connected.
if($connect === false){
    echo 'Failed to connect!';
} else{
    echo 'We are connected!';
}
*/